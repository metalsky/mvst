/*  RPM execution forwarder
 *  based on the: GCC execution forwarder
 *     Written by Michael Eager <eager@mvista.com>
 *
 *     Copyright (c) 2001 MontaVista Software, Inc.
 *
 *  RPM changes by: Mark Hatle <fray@mvista.com>
 *   Copyright (c) 2003-2004 MontaVista Software, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 *
 * The purpose of this forwarder is to set the library PATH,
 * and then to execute the actual program...
 * 
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define xmalloc(n) malloc(n)
#define MAXPATHLEN 4096

#ifndef GET_ENV_PATH_LIST
#define GET_ENV_PATH_LIST(VAR,NAME)     do { (VAR) = getenv (NAME); } while (0)
#endif

#define PUT_ENV(VAR,VALUE)					\
  do {								\
     char *tmp = xmalloc(strlen(VAR)+1+strlen(VALUE)+1);        \
     strcpy (tmp, VAR);						\
     strcat (tmp, "=");						\
     strcat (tmp, VALUE);					\
     if (putenv (tmp) != 0) {					\
       fprintf (stderr, "%s: Out of environment space\n", arg0); \
       exit (1);						\
     }								\
  } while(0);


#ifndef PROG_TO_EXEC 
#define PROG_TO_EXEC "true"
#endif

#define setrelpath(PATH,VAL)                                    \
  do {                                                          \
    char *tmp = xmalloc(strlen(realpath)+strlen(VAL)+1);        \
    tmp[0]='\0';                                                \
    strcat (tmp, realpath);                                     \
    strcat (tmp, VAL);                                          \
    remove_relative_paths (tmp);                                \
    PATH = tmp;                                                 \
  } while (0)


extern int find_real_path (const char * filename, const char * pathlist,
                    char * realpath, char * realname); 

extern void remove_relative_paths (char * path);

int main (int argc, char *argv[]) 
{
   char *realpath = xmalloc(MAXPATHLEN); 
   char *realname = xmalloc(MAXPATHLEN);
   char *rpm_edition_prefix;
   char *rpm_exec_prefix;
   char *rpm_lib_prefix;
   char *apt_bin_path;
   char *apt_rpm_path;
   char arg0[1024];
   char **exec_args=NULL;
   int num_exec_args=0;
   char *PATH;
   int i;

   strcpy (arg0, argv[0]);

   GET_ENV_PATH_LIST (PATH, "PATH");
   if (find_real_path (arg0, PATH, realpath, realname) != 0) 
   { 
     fprintf (stderr, "%s: Error searching $PATH (%s)\n", arg0, PATH);
     exit(1); 
   }

   setrelpath (rpm_edition_prefix, "../");
 
   setrelpath (rpm_exec_prefix, "../apt/lib/rpm/");
   rpm_exec_prefix = (char *) realloc(rpm_exec_prefix, strlen(rpm_exec_prefix) + strlen(PROG_TO_EXEC) + 1);
   strcat (rpm_exec_prefix, PROG_TO_EXEC);
   
   /* start with common/lib/rpm in path list */
   setrelpath(apt_rpm_path, "../apt/lib/rpm/:");
   
   /* add common/bin next in the path list */
   setrelpath(apt_bin_path, "../bin:");
   apt_rpm_path = (char *) realloc(apt_rpm_path, strlen(apt_rpm_path) + strlen(apt_bin_path) + 1);
   strcat(apt_rpm_path, apt_bin_path);
   
   /* add rest of PATH to the end of the path list*/
   apt_rpm_path = (char *) realloc(apt_rpm_path, strlen(apt_rpm_path) + strlen(PATH) + 1);
   strcat(apt_rpm_path, PATH);
   
   setrelpath (rpm_lib_prefix, "../apt/lib/:/usr/lib/lwp");
   
   for (i = 0; i < argc; i++)
   {
     if (strcmp (argv[i], "-vv") == 0) 
     {
        fprintf (stderr, "%s: Actual path = '%s'\n\tActual name = '%s'\n", 
	  arg0, realpath, realname);
	fprintf (stderr, "\texport PATH=%s\n", apt_rpm_path);
	fprintf (stderr, "\texport LD_LIBRARY_PATH=%s\n", rpm_lib_prefix);
	fprintf (stderr, "\texport MVL_RPM_EDITION_ROOT=%s\n", rpm_edition_prefix);
        fprintf (stderr, "\tInvoking %s\n", rpm_exec_prefix);
     } 
     else {
	num_exec_args++;
	exec_args = (char **)realloc(exec_args, sizeof(char *)*num_exec_args);
	exec_args[num_exec_args-1]=argv[i];
     }
   }
   /* Null termination */
   exec_args = (char **)realloc(exec_args, sizeof(char *)*num_exec_args+1);
   exec_args[num_exec_args]=NULL;


   PUT_ENV("PATH", apt_rpm_path);
   PUT_ENV("LD_LIBRARY_PATH", rpm_lib_prefix);
   PUT_ENV("MVL_RPM_EDITION_ROOT", rpm_edition_prefix);

   /*  Call desired program with complete path. */
   exec_args[0] = rpm_exec_prefix;

   if (num_exec_args != argc)
   {
      printf("Program arguments: ");
      for (i=0; i<num_exec_args;i++)
	  printf("%s, ", exec_args[i]);
      printf("\n");
   }

   execv (rpm_exec_prefix, exec_args);

   /* If we get here, there was an error! */
   strcat (arg0, ": ");
   strcat (arg0, rpm_exec_prefix);
   perror (arg0);
   exit(1);
}
