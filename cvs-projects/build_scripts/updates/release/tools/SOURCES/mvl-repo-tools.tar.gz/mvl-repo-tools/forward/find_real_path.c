/*  Find the real path to an argument
 *
 *  based on the: GCC execution forwarder
 *     Written by Michael Eager <eager@mvista.com>
 *
 *     Copyright (c) 2001 MontaVista Software, Inc.
 *
 *  RPM changes by: Mark Hatle <fray@mvista.com>
 *   Copyright (c) 2003-2004 MontaVista Software, Inc.
 *
 *  (Double // parsing)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

#ifndef MAXPATHLEN
#define MAXPATHLEN 4096
#endif
#define DIR_SEPARATOR '/'
#define PATH_SEPARATOR ':'

#define xmalloc(x) malloc(x)


void remove_relative_paths (char * path);

/*  Find Real Path for file  
 *  
 *  If filename is a simple name (not absolute or relative path)
 *  search for it on pathlist to find full path.
 *
 *  Replace any relative path links (. or ..).
 * 
 *  Replace any symbolic links with actual path.
 *
 *  Sets realpath to coanonical path (ends with a /) and realname 
 *  to actual name (may have been altered by link).
 *  
 *  Return 0 on success, <0 if stat fails, >0 if not found.
 */

int 
find_real_path (const char * filename, const char * pathlist,
                    char * realpath, char * realname)
{
  int ret;
  char *fullpath = xmalloc(MAXPATHLEN);
  char *linkfile = xmalloc(MAXPATHLEN);
  char *p, *q, *s, *t;
  const char *beg, *end;
  int i, off, len;
  struct stat file;

  *realpath = '\0';

  if (strchr (filename, '/'))
  {
    if (filename[0] == '/')
    {
      /* We have absolute path */
      strcpy (fullpath, filename);
    }
    else
    {
      /* We have relative path, prepend $cwd */
      getcwd (fullpath, MAXPATHLEN);
      strcat (fullpath, "/");
      strcat (fullpath, filename);
    }
  }
  else
  {
    /* Search pathlist for matching filename  */
    beg = pathlist;
    while (1)
    {
      for (end = beg; *end && *end != PATH_SEPARATOR; end++) ;
      strncpy (fullpath, beg, end - beg);
      fullpath[end - beg] = '\0';
      if (strcmp (fullpath, ".") == 0)
        getcwd (fullpath, MAXPATHLEN);
      strcat (fullpath, "/");
      strcat (fullpath, filename);
      if ((lstat (fullpath, &file) == 0) &&
        (S_ISREG(file.st_mode) || S_ISLNK(file.st_mode))) break;
      if (*end == '\0') 
	return 1;		/* Not found on path */
      beg = end + 1;
    } 
  }
  /*
   *  We now have full path, but there may be relative paths or links
   *  Replace any relative paths
   *  Check the full path and replace any link.
   *  Work back along the path and do again and again.
   */

  remove_relative_paths (fullpath);

  while (fullpath[0])
  {
    while ((ret = lstat (fullpath, &file)) == 0 && S_ISLNK(file.st_mode))
    {
      /* fullpath is a link */
      linkfile[readlink (fullpath, linkfile, MAXPATHLEN)] = '\0';
      if (linkfile[0] == DIR_SEPARATOR)
      {
        /* Link replaces path */
        strcpy (fullpath, linkfile);
      }
      else
      {
        /* Link is relative to current directory */
        q = strrchr (fullpath, DIR_SEPARATOR);
        *(q + 1) = '\0';
        strcat (fullpath, linkfile);
      }
      /* We might have added more relative paths -- remove them */
      remove_relative_paths (fullpath);
    }

    if (ret)
    {
      free (fullpath);
      free (linkfile);
      return ret;
    }

    /* Strip off the last segment of the path */
    if ((q = strrchr (fullpath, DIR_SEPARATOR)))
      *q++ = '\0';
    else
      q = fullpath;

    /* Shift realpath right to make room for new segment and slash */
    off = strlen (q) + 1;
    len = strlen (realpath);
    for (i = len; i >= 0; i--)
      realpath [off + i] = realpath [i];

    /* Copy new segment to realpath */
    s = q;
    t = realpath + 1;
    while (*s)
      *t++ = *s++;

    /* Stick in separator at beginning of segment. */
    realpath[0] = DIR_SEPARATOR;
  }
  /* Split executable name from path */
  p = strrchr (realpath, DIR_SEPARATOR);
  strcpy (realname, p + 1);
  *++p = '\0';

  free (fullpath);
  free (linkfile);
  return 0;
}


/* Remove relative paths -- .. and . */
void
remove_relative_paths (char * path)
{
  char *p, *s;

  p = path;
  while ((p = strchr (p, DIR_SEPARATOR)))
  {
    p++;
    if (*p == DIR_SEPARATOR)
    {
      /* Translate "//" ==> "/" */
      /* (except at the beginning since //<path> is special */
      if ( p > path+1 )
      {
        memmove (p-1, p, strlen(p) + 1);
        p--; /* Move back */
      }
      continue;
    }

    if (*p == '.')
    {
      p++;
      if (*p == DIR_SEPARATOR)
      {
        /*  Translate "/./" ==> "/"  */
        memmove (p-2, p, strlen(p) + 1);
        p-=2;
      }
      else if (*p == '.' && *(p+1) == DIR_SEPARATOR)
      {
        /*  Translate "/<whatever>/../" ==> "/"  */
        s = p + 1;
        p -= 3;
        while ( p > path && *p != DIR_SEPARATOR)
          p--;
        memmove (p, s, strlen(s) + 1);
      }

    }
  }
}
